/* PCL Core plugin — prevents directory listing, standard WordPress guard */
<?php
